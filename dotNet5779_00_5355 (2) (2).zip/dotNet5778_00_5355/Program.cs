﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5778_00_5355
{
    class Program
    {
        static void Main(string[] args)
        {
            WelcomewMethod();
            Console.ReadKey();
        }

        private static void WelcomewMethod()
        {
            Console.WriteLine("Enter your name: ");
            string userName = Console.ReadLine();
            Console.WriteLine(userName + " Welcome to my first console application");
        }
    }
}
